<?php

/**
 * Modelo de tipo de estado
 */

class Types
{
    private $id;
    private $name;
    private $pdo;

    public function __construct()
    {
        try {
            $this->pdo = new Database;
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }
    
    public function getAll()
    {
        try {
            //$strSql = "SELECT c.*, s.name as status FROM categories c INNER JOIN  statuses s ON s.id=c.status_id";
            $strSql = "SELECT * from type_statuses";
            $query = $this->pdo->select($strSql);
            return $query;
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }
    public function newTypes($data)
    {
        try {
            //$data['status_id'] = 1;
            $this->pdo->insert('type_statuses', $data);
            //return true;
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }
    public function editTypes($data)
    {
        try{
            $strWhere='id='.$data['id'];
            $this->pdo->update('type_statuses',$data,$strWhere);
        }catch(PDOException $e){
            die($e->getMessage());
        }
    }
    public function deleteTypes($data)
    {
        try{
            $strWhere='id='.$data['id'];
            $this->pdo->delete('type_statuses',$strWhere);
        }catch(PDOException $e){
            die($e->getMessage());
        }
    }
    public function getById($id)
    {
        try{
            $strSql="SELECT * FROM type_statuses WHERE id=:id";
            $array=['id'=>$id];
            $query=$this->pdo->select($strSql,$array);
            return $query;
        }catch(PDOException $e){
            die($e->getMessage());
        }
    }
}

?>