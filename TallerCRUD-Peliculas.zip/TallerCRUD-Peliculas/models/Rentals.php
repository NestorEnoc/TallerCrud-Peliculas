<?php

/**
 * Modelo de rentals
 */

 class Rentals
    {
     private $id;
     private $start_date;
     private $end_date;
     private $total;
     private $user_id;
     private $status_id;
     private $pdo;

    public function __construct()
    {
        try {
            $this->pdo = new Database;
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }
    
    public function getAll()
    {
        try {
            //$strSql = "SELECT c.*, s.name as status FROM categories c INNER JOIN  statuses s ON s.id=c.status_id";
            //$strSql = "SELECT c.*, s.name as status FROM categories c INNER JOIN  statuses s ON s.id=c.status_id";
            $strSql = "SELECT r.*, u.name as usuario , s.name as status from rentals r inner join users u on u.id= r.user_id inner join statuses s on r.status_id=s.id group by r.id";
            $query = $this->pdo->select($strSql);
            return $query;
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }
    public function newRentals($data)
    {
        try {
            //$data['status_id'] = 1;
            $this->pdo->insert('rentals', $data);
            return true;
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }
    public function editRentals($data)
    {
        try{
            $strWhere='id='.$data['id'];
            $this->pdo->update('rentals',$data,$strWhere);
        }catch(PDOException $e){
            die($e->getMessage());
        }
    }
    public function deleteRentals($data)
    {
        try{
            $strWhere='id='.$data['id'];
            $this->pdo->delete('rentals',$strWhere);
        }catch(PDOException $e){
            die($e->getMessage());
        }
    }
    public function getById($id)
    {
        try{
            $strSql="SELECT * FROM rentals WHERE id=:id";
            $array=['id'=>$id];
            $query=$this->pdo->select($strSql,$array);
            return $query;
        }catch(PDOException $e){
            die($e->getMessage());
        }
    }

    public function getLastId()
    {
        try {
            $strSql = "SELECT MAX(id) as id FROM rentals";
            $query = $this->pdo->select($strSql);
            return $query;
        } catch (PDOException $e) {
            return $e->getMessage();
        }
    }

    public function saveRentalsMovie($arrayMovies, $lastIdMovie)
    {
        try {
            foreach ($arrayMovies as $movie) {
                $data = [
                    'movie_id'    =>  $movie["id"],
                    'rental_id'   =>  $lastIdMovie,
                ];

                $this->pdo->insert('movie_rental', $data);
            } 

            return true;
        } catch (PDOException $e) {
            return $e->getMessage();
        }    
    }
 }