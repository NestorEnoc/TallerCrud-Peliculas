<?php

require 'models/Types.php';
require 'models/Status.php';

class TypesController
{
    private $model;
    private $status;

    public function __construct()
    {
        $this->model = new Types;
        $this->status = new Status;
    }

    public function index()
    {
        require 'views/layout.php';
        $types = $this->model->getAll();
        require 'views/types/list.php';
    }
    public function new()
    {
        require 'views/layout.php';
        require 'views/types/new.php';
    }
    public function save()
    {
        $this->model->newTypes($_REQUEST);
        header('Location: ?controller=types');
    }
    public function edit()
    {
        if (isset($_REQUEST['id'])) {
            $id = $_REQUEST['id'];

            $data = $this->model->getById($id);
            $statuses = $this->status->getAll();
            require 'views/layout.php';
            require 'views/types/edit.php';
        } else {
            echo "Error, no se realizo.";
        }
    }
    public function update()
    {
        if (isset($_POST)) {
            $this->model->editTypes($_POST);
            header('Location: ?controller=types');
        } else {
            echo "Error, no se realizo.";
        }
    }
    public function delete()
    {
        $this->model->deleteTypes($_REQUEST);
        header('Location: ?controller=types');
    }
}