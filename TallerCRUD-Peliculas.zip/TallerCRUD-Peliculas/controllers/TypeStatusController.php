<?php

/**
 * summary
 */
class TypeStatusController
{
    /**
     * summary
     */
    public function __construct()
    {
        
    }

    public function index()
    {
    	require 'views/layout.php';
    }
}