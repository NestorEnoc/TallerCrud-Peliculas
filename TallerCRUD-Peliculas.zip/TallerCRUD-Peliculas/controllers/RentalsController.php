<?php

require 'models/Rentals.php';
require 'models/Status.php';
require 'models/Movie.php';
require 'models/User.php';
require 'models/Category.php';

class RentalsController
{
    private $model;
    private $status;
    private $movie;
    private $users;

    public function __construct()
    {
        $this->model = new Rentals;
        $this->status = new Status;
        $this->movie = new Movie;
        $this->users = new User;
    }
    public function index()
    {
        require 'views/layout.php';
        $rentals = $this->model->getAll();
        require 'views/rentals/list.php';
    }
    public function new()
    {
        $users = $this->users->getAll();
        $statuses = $this->status->getAll();
        $Movies = $this->movie->getAll();
        require 'views/layout.php';
        require 'views/rentals/new.php';
    }
    public function save()
    {
        //$this->model->newRentals($_REQUEST);
        //header('Location: ?controller=rentals');

         //Organizar en un array los datos de la tabla movie
         $dataMovie = [
            'start_date' 	=> $_POST['start_date'],
            'end_date' 		=> $_POST['end_date'],  
            'total'		    => $_POST['total'],
            'user_id'		=> $_POST['user_id'],
            'status_id'     => $_POST['status_id']
        ];

        //Array de categorias
        $arrayMovies = isset($_POST['Movies']) ? $_POST['Movies'] : [];    

        if(!empty($arrayMovies)) {
            //Inserción de la Tabla Movie
            $respMovie = $this->model->newRentals($dataMovie);
            //Obtener el ultimo ID registrado
            $lastIdMovie = $this->model->getLastId();
            //Inserción de la Tabla category_movie
            $respRentalsMovie = $this->model->saveRentalsMovie($arrayMovies, $lastIdMovie[0]->id);

        } else {
            $respMovie         = false;
            $respRentalsMovie  = false;            
        }

        $arrayResp = [];

        if($respMovie == true && $respRentalsMovie == true) {
            $arrayResp = [
                'success' => true,
                'message' => "Pelicula Creada"  
            ];
        } else {
            $arrayResp = [
                'error' => true,
                'message' => "Error Creando la Pelicula"  
            ];
        }

        echo json_encode($arrayResp);
        return;

    }
    public function edit()
    {
        if (isset($_REQUEST['id'])) {
            $id = $_REQUEST['id'];

            $data = $this->model->getById($id);
            $users = $this->users->getAll();
            $statuses = $this->status->getAll();
            require 'views/layout.php';
            require 'views/rentals/edit.php';
        } else {
            echo "Error, no se realizo.";
        }
    }
    public function update()
    {
        if (isset($_POST)) {
            $this->model->editRentals($_POST);
            header('Location: ?controller=rentals');
        } else {
            echo "Error, no se realizo.";
        }
    }
    public function delete()
    {
        $this->model->deleteRentals($_REQUEST);
        header('Location: ?controller=rentals');
    }
}
