<?php

require 'models/Role.php';
require 'models/Status.php';

class RoleController
{
    private $model;
    private $status;

    public function __construct()
    {
        //var_dump("entro");
        $this->model = new Role;
        $this->status = new Status;
    }

    public function index()
    {
        $roles = $this->model->getAll();
        //var_dump($roles);
        require 'views/layout.php';
        require 'views/roles/list.php';
    }
    
    public function new()
    {
        $statuses = $this->status->getAll();
        require 'views/layout.php';
        require 'views/roles/new.php';
    }
    public function save()
    {
        $this->model->newRole($_REQUEST);
        header('Location: ?controller=role');
    }
    public function edit()
    {
        if(isset($_REQUEST)){
            $id=$_REQUEST['id'];

            $statuses = $this->status->getAll();
            $data=$this->model->getById($id);
            require 'views/layout.php';
            require 'views/roles/edit.php';
        }else{
            echo "Error, no se realizo.";
        }
    }
    public function update()
    {
        if(isset($_POST)){
            $this->model->editRole($_POST);
            header('Location: ?controller=role');
        }else{
            echo "Error, no se realizo";
        }
    }
    public function delete()
    {
        $this->model->deleteRole($_REQUEST);
        header('Location: ?controller=role');
    }
 }
 ?>
