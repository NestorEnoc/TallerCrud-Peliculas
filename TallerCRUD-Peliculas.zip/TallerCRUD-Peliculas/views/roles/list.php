<main class="container">
	<section class="col-md-12 text-center">
		<h1>Listado de Roles</h1>

		<div class="col-md-12 m-2 d-flex justify-content-between">
			<h2>Roles</h2>
			<a href="?controller=role&method=new" class="btn btn-success">Agregar</a>
		</div>

		<section class="col-md-12">
			<table class="table table-striped table-hover">
			  <thead>
			    <tr>
			      <th>#</th>
			      <th>Nombre</th>
			      <th>Estado</th>
			      <th>Acciones</th>
			    </tr>
			  </thead>
			  <tbody>
			  	<?php foreach($roles as $role) :?>
				    <tr>
				      <td><?php echo $role->id ?></td>
				      <td><?php echo $role->name ?></td>
				      <td><?php echo $role->status ?></td>
					  <td>
						<a href="?controller=role&method=edit&id=<?php echo $role->id ?>" class="btn btn-warning">Editar</a>
						<a href="?controller=role&method=delete&id=<?php echo $role->id ?>" class="btn btn-danger">Eliminar</a>
				      </td>				      
				    </tr>
				  <?php endforeach ?>		    
			  </tbody>
			</table>
		</section>
	</section>
</main>