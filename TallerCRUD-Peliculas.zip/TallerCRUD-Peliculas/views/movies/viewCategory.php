<main class="container">

    <section class="col-md-12 text-center">
		<h1>Categoria de la Pelicula</h1>

		<div class="col-md-12 m-2 d-flex justify-content-between">
			<h2>Categorias</h2>
		</div>

        <section class="col-md-12 flex-nowrap table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Pelicula</th>
                        <th>Categoria</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <?php echo $data[0]->id?>
                        </td>
                        <td>
                            <?php echo $data[0]->nombre ?>
                        </td>
                        <td>
                            <?php echo $data[0]->name ?>
                        </td>
                        <td>
                            <a href="?controller=movie" class="btn btn-success">Regresar</a>
                        </td>
                    </tr>
                </tbody>
			</table>
		</section>
	</section>
</main>