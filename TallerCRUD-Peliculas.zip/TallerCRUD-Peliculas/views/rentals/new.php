<main class="container">
    <div class="row">
        <h1 class="col-12 d-flex jutify-content-center">Nueva Renta</h1>
    </div>

    <section class="row mt-5">
        <div class="card w-50 m-auto">
            <div class="card-header container">
                <h2 class="m-auto">Informacion Rentas</h2>
            </div>

            <div class="card-body w-100">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <div class="form-group">
                                <label> Fecha de Inicio</label>
                                <input type="date" id="start_date" class="form-control" placeholder="Ingrese el nombre">
                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="form-group">
                                <label> Fecha de Fin</label>
                                <input type="date" id="end_date" class="form-control" placeholder="Ingrese su nombre">
                            </div>
                        </div>
                    </div>

                    <!--<div class="form-group">
                        <label> Usuario</label>
                        <input type="text" id="user_id" class="form-control" placeholder="Ingrese su contraseña">
                    </div>-->

                    <div class="form-group">
                        <label>Usuario</label>
                        <select id="user_id" class="form-control">
                            <option value="">Seleccione...</option>
                            <?php 
                            	foreach($users as $user) {
                            		if($user->id === $data[0]->user_id) {
                            ?>
                                		<option selected value="<?php echo $user->id ?>"><?php echo $user->name ?></option>
                            <?php
                            		} else {
                            ?>
                                		<option value="<?php echo $user->id ?>"><?php echo $user->name ?></option>
                            <?php
                            		}
                            	} 
                            ?>
                        </select>
                    </div>

                    <!--<div class="form-group">
                        <label> Estado</label>
                        <input type="text" id="status_id" class="form-control" placeholder="Ingrese su contraseña">
                    </div>-->

                    <div class="form-group">
                        <label>Estado</label>
                        <select id="status_id" class="form-control">
                            <option value="">Seleccione...</option>
                            <?php 
                            	foreach($statuses as $status) {
                            		if($status->id === $data[0]->status_id) {
                            ?>
                                		<option selected value="<?php echo $status->id ?>"><?php echo $status->name ?></option>
                            <?php
                            		} else {
                            ?>
                                		<option value="<?php echo $status->id ?>"><?php echo $status->name ?></option>
                            <?php
                            		}
                            	} 
                            ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label> Total</label>
                        <input type="text" id="total" class="form-control" placeholder="Ingrese el valor total">
                    </div>
                    
                    <div class="form-group row">
                    <div class="col-md-8">                            
                        <label>Peliculas</label>
                        <select id="movie" class="form-control">
                            <option value="">Seleccione...</option>
                            <?php foreach($Movies as $movie): ?>
                                <option value="<?php echo $movie->id ?>"><?php echo $movie->name ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                    <div class="col-md-4 mt-4">
                        <a href="#" class="btn btn-success" id="addElement"> + </a>
                    </div>
                </div>                    

                <div id="list-Movies" class="form-group"></div>

                    <div class="form-group">
                        <button class="btn btn-primary" id="save">Generar</button>
                    </div>
                    </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
</main>

<script src="assets/js/rentals.js"></script>