-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-09-2020 a las 22:42:17
-- Versión del servidor: 10.4.14-MariaDB
-- Versión de PHP: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `example`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `categories`
--

INSERT INTO `categories` (`id`, `name`, `status_id`, `created_at`, `updated_at`) VALUES
(1, 'Business-focused asynchronous architectures', 2, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(2, 'Diverse fault-tolerant systemengines', 2, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(3, 'Compatible non-volatile systemengines', 3, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(4, 'Diverse analyzing artificialintelligence', 3, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(5, 'Progressive reciprocal capacity', 1, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(6, 'Polarised executive extranet', 1, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(7, 'Pre-emptive heuristic alliance', 1, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(8, 'Phased multi-state superstructure', 1, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(9, 'Self-enabling directional firmware', 1, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(10, 'Multi-channelled needs-based leverage', 1, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(11, 'otros', 4, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `category_movie`
--

CREATE TABLE `category_movie` (
  `id` int(10) UNSIGNED NOT NULL,
  `movie_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `category_movie`
--

INSERT INTO `category_movie` (`id`, `movie_id`, `category_id`, `created_at`, `updated_at`) VALUES
(1, 4, 4, NULL, NULL),
(2, 4, 5, NULL, NULL),
(3, 1, 1, NULL, NULL),
(4, 1, 9, NULL, NULL),
(5, 1, 10, NULL, NULL),
(6, 7, 8, NULL, NULL),
(7, 11, 9, NULL, NULL),
(8, 11, 6, NULL, NULL),
(9, 12, 11, NULL, NULL),
(10, 13, 3, NULL, NULL),
(11, 13, 5, NULL, NULL),
(12, 13, 10, NULL, NULL),
(13, 14, 7, NULL, NULL),
(14, 15, 6, NULL, NULL),
(15, 15, 9, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movies`
--

CREATE TABLE `movies` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `status_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `movies`
--

INSERT INTO `movies` (`id`, `name`, `description`, `user_id`, `status_id`, `created_at`, `updated_at`) VALUES
(1, 'Motor Vehicle Inspector', 'Mouse only growled in reply. \'Idiot!\' said the Mouse. \'--I proceed. \"Edwin and Morcar, the earls of Mercia and Northumbria--\"\' \'Ugh!\' said the Gryphon. \'We can do without lobsters, you know. Which.', 4, 1, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(2, 'Recordkeeping Clerk', 'And then, turning to Alice, and sighing. \'It IS the same tone, exactly as if it wasn\'t trouble enough hatching the eggs,\' said the Dodo. Then they all spoke at once, in a great hurry. \'You did!\'.', 6, 1, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(3, 'System Administrator', 'However, \'jury-men\' would have this cat removed!\' The Queen had only one who got any advantage from the sky! Ugh, Serpent!\' \'But I\'m NOT a serpent, I tell you!\' But she did so, and were resting in.', 10, 1, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(4, 'Fitness Trainer', 'I\'ve finished.\' So they began moving about again, and we put a stop to this,\' she said to Alice; and Alice looked up, and there was no more of the ground, Alice soon came to ME, and told me he was.', 3, 1, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(6, 'Project Manager', 'Majesty,\' said Alice angrily. \'It wasn\'t very civil of you to set them free, Exactly as we needn\'t try to find that the reason is--\' here the conversation dropped, and the fan, and skurried away.', 4, 1, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(7, 'Machine Operator', 'Cat. \'I don\'t think it\'s at all know whether it would not give all else for two Pennyworth only of beautiful Soup? Beau--ootiful Soo--oop! Soo--oop of the jury consider their verdict,\' the King was.', 10, 1, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(9, 'Order Filler', 'Dormouse!\' And they pinched it on both sides of it, and they repeated their arguments to her, one on each side, and opened their eyes and mouths so VERY much out of the Lobster Quadrille, that she.', 3, 1, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(11, 'Project Manager', 'is a movie very happy', 12, 1, NULL, NULL),
(12, 'moby dick', 'Moby Dick es una película estadounidense de 1956, dirigida por John Huston y protagonizada por Gregory Peck, Richard Basehart, Leo Genn, James .', 18, 1, NULL, NULL),
(13, ' The Fast and the Furious', '\nThe Fast and the Furious', 4, 1, NULL, NULL),
(14, ' Pirates of the Caribbean: The Curse of the Black', '\nPirates of the Caribbean: The Curse of the Black', 10, 1, NULL, NULL),
(15, 'Who am I: Ningún sistema es seguro', 'Who am I: Ningún sistema es seguro?', 6, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movie_rental`
--

CREATE TABLE `movie_rental` (
  `id` int(10) UNSIGNED NOT NULL,
  `movie_id` int(10) UNSIGNED NOT NULL,
  `rental_id` int(10) UNSIGNED NOT NULL,
  `price` double NOT NULL,
  `observations` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `movie_rental`
--

INSERT INTO `movie_rental` (`id`, `movie_id`, `rental_id`, `price`, `observations`, `created_at`, `updated_at`) VALUES
(1, 1, 4, 11000, 'nothing', NULL, NULL),
(2, 9, 23, 0, NULL, NULL, NULL),
(3, 4, 24, 0, NULL, NULL, NULL),
(4, 6, 25, 0, NULL, NULL, NULL),
(5, 2, 25, 0, NULL, NULL, NULL),
(6, 4, 43, 0, NULL, NULL, NULL),
(7, 9, 45, 0, NULL, NULL, NULL),
(8, 3, 49, 0, NULL, NULL, NULL),
(9, 3, 50, 0, NULL, NULL, NULL),
(10, 4, 52, 0, NULL, NULL, NULL),
(11, 4, 53, 0, NULL, NULL, NULL),
(12, 9, 54, 0, NULL, NULL, NULL),
(13, 12, 55, 0, NULL, NULL, NULL),
(14, 14, 55, 0, NULL, NULL, NULL),
(15, 7, 56, 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rentals`
--

CREATE TABLE `rentals` (
  `id` int(10) UNSIGNED NOT NULL,
  `start_date` date NOT NULL DEFAULT current_timestamp(),
  `end_date` date DEFAULT NULL,
  `total` double DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `status_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `rentals`
--

INSERT INTO `rentals` (`id`, `start_date`, `end_date`, `total`, `user_id`, `status_id`, `created_at`, `updated_at`) VALUES
(1, '2001-01-29', '2018-03-15', 13533, 7, 1, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(2, '1970-08-13', '1986-12-07', 187906616.79467, 5, 1, '2020-08-21 23:18:11', '2020-08-21 23:18:11'),
(3, '1996-03-27', '2008-02-28', 310840126.95, 1, 1, '2020-08-21 23:18:11', '2020-08-21 23:18:11'),
(4, '1979-07-22', '1988-01-28', 2626, 18, 3, '2020-08-21 23:18:11', '2020-08-21 23:18:11'),
(5, '1989-07-05', '1979-10-22', 5022, 4, 1, '2020-08-21 23:18:11', '2020-08-21 23:18:11'),
(6, '2011-07-16', '2016-07-28', 4358664, 3, 1, '2020-08-21 23:18:11', '2020-08-21 23:18:11'),
(7, '2017-06-01', '1984-11-21', 22968656.658, 5, 1, '2020-08-21 23:18:11', '2020-08-21 23:18:11'),
(8, '1977-05-27', '1987-04-16', 3237874.9559, 6, 1, '2020-08-21 23:18:11', '2020-08-21 23:18:11'),
(9, '1971-09-21', '2015-07-26', 95.3935589, 3, 1, '2020-08-21 23:18:11', '2020-08-21 23:18:11'),
(10, '1980-06-22', '2001-09-17', 81.45064174, 9, 1, '2020-08-21 23:18:11', '2020-08-21 23:18:11'),
(11, '2021-09-12', '2021-09-12', 1500, 1, 2, NULL, NULL),
(12, '2011-09-11', '2020-09-12', 58000, 1, 1, NULL, NULL),
(14, '2020-09-10', '2019-07-10', 110000, 1, 1, NULL, NULL),
(15, '2020-09-10', '2019-07-10', 110000, 1, 1, NULL, NULL),
(19, '1996-03-27', '2020-09-20', 2029, 1, 1, NULL, NULL),
(23, '0000-00-00', '0000-00-00', 9000, 1, 1, NULL, NULL),
(24, '2001-09-17', '2001-09-17', 1000, 1, 1, NULL, NULL),
(25, '2001-09-17', '2001-09-17', 25000, 1, 2, NULL, NULL),
(26, '1988-01-28', '1990-01-28', 135339, 7, 2, NULL, NULL),
(27, '1988-01-28', '1990-01-28', 135339, 7, 2, NULL, NULL),
(28, '1988-01-28', '0000-00-00', 23000, 3, 1, NULL, NULL),
(29, '1988-01-28', '1988-01-28', 135339, 1, 1, NULL, NULL),
(30, '1988-01-28', '1988-01-28', 135339, 1, 1, NULL, NULL),
(31, '1988-01-28', '1988-01-28', 135339, 1, 1, NULL, NULL),
(32, '1988-01-28', '1988-01-28', 23000, 1, 1, NULL, NULL),
(33, '2001-09-17', '2001-09-17', 135339, 1, 1, NULL, NULL),
(34, '2001-09-17', '2001-09-17', 135339, 1, 1, NULL, NULL),
(35, '2001-09-17', '2001-09-17', 135339, 1, 1, NULL, NULL),
(36, '2001-09-17', '2001-09-17', 135339, 1, 1, NULL, NULL),
(38, '1988-01-28', '2001-09-17', 135339, 1, 1, NULL, NULL),
(39, '1988-01-28', '2001-09-17', 135339, 1, 1, NULL, NULL),
(40, '2001-09-17', '2001-09-17', 23000, 1, 1, NULL, NULL),
(41, '1988-01-28', '2001-09-17', 23000, 1, 1, NULL, NULL),
(42, '1988-01-28', '1988-01-28', 135339, 1, 1, NULL, NULL),
(43, '1988-01-28', '1988-01-28', 135339, 1, 1, NULL, NULL),
(44, '2001-09-17', '1988-01-28', 23000, 4, 2, NULL, NULL),
(45, '2001-09-17', '1988-01-28', 23000, 4, 2, NULL, NULL),
(46, '1988-01-28', '1988-01-28', 25000, 1, 1, NULL, NULL),
(47, '1988-01-28', '1988-01-28', 25000, 1, 1, NULL, NULL),
(48, '1988-01-28', '1988-01-28', 25000, 1, 1, NULL, NULL),
(49, '1988-01-28', '1988-01-28', 25000, 1, 1, NULL, NULL),
(50, '1988-01-28', '1988-01-28', 25000, 1, 1, NULL, NULL),
(52, '2002-01-29', '2002-01-29', 23000, 1, 1, NULL, NULL),
(53, '2001-09-17', '2002-01-29', 23000, 18, 1, NULL, NULL),
(54, '2020-02-12', '2020-11-26', 23000, 18, 1, NULL, NULL),
(55, '2020-09-09', '2020-09-29', 23000, 18, 1, NULL, NULL),
(56, '2020-09-03', '2020-09-01', 23000, 14, 2, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `name`, `status_id`, `created_at`, `updated_at`) VALUES
(1, 'Administrador', 1, '2020-08-21 23:18:08', '2020-08-21 23:18:08'),
(2, 'Empleado', 2, '2020-08-21 23:18:08', '2020-08-21 23:18:08'),
(3, 'Cliente', 1, '2020-08-21 23:18:08', '2020-08-21 23:18:08'),
(4, 'propietario', 1, NULL, NULL),
(5, 'otro', 3, NULL, NULL),
(6, 'otro3', 1, NULL, NULL),
(7, 'En marcha', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `statuses`
--

CREATE TABLE `statuses` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type_status_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `statuses`
--

INSERT INTO `statuses` (`id`, `name`, `type_status_id`, `created_at`, `updated_at`) VALUES
(1, 'Activo', 1, '2020-08-21 23:18:08', '2020-08-21 23:18:08'),
(2, 'Inactivo', 1, '2020-08-21 23:18:08', '2020-08-21 23:18:08'),
(3, 'Bloqueado', 2, '2020-08-22 01:04:59', '2020-08-22 01:04:59'),
(4, 'Alquilado', 3, '2020-08-22 01:05:19', '2020-08-22 01:05:19'),
(5, 'Disponible', 3, '2020-08-22 01:05:19', '2020-08-22 01:05:39'),
(24, 'pendiente', 7, NULL, NULL),
(27, 'En espera', 3, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `type_statuses`
--

CREATE TABLE `type_statuses` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `type_statuses`
--

INSERT INTO `type_statuses` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'General', '2020-08-21 23:18:08', '2020-08-21 23:18:08'),
(2, 'Usuario', '2020-08-21 23:18:08', '2020-08-21 23:18:08'),
(3, 'Peliculas', '2020-08-21 23:18:08', '2020-08-21 23:18:08'),
(7, 'otro', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `status_id`, `role_id`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Zachary Reilly', 'bradtke.may@kertzmann.info.com', NULL, '$2y$10$Ni9N6uqT3eV4D8PsyYBMxuwE1zSH4aMoGsy46NvM/vE9nyXY5Ce0G', 1, 3, NULL, '2020-08-21 23:18:09', '2020-08-21 23:18:09'),
(2, 'Dr. Cruz Jenkins', 'lueilwitz.kaia@gaylord.biz', NULL, '$2y$10$qW4F92em18XBx4kzwg6lI.JIUnttGnR.6p1vLCJuN2LT5pe4Kj5Jm', 1, 2, NULL, '2020-08-21 23:18:09', '2020-08-21 23:21:42'),
(3, 'Cruz Stamm II', 'dewayne49@gmail.com', NULL, '$2y$10$sLadSaNraZswCJ.KAfPjZeKPaxlR6v5hLw9TeELNE/KhL7vFHJccG', 1, 1, NULL, '2020-08-21 23:18:09', '2020-08-21 23:18:09'),
(4, 'Lorenzo Fay', 'jayme63@gmail.com', NULL, '$2y$10$yA3DzcGLioM3NEZsoQPXWurZtt/lMpsrj98/zJT9ffyBbjU1QGZTS', 2, 2, NULL, '2020-08-21 23:18:09', '2020-08-21 23:21:51'),
(5, 'Otho Greenholt', 'jaskolski.estrella@hotmail.com', NULL, '$2y$10$GPQTSFqd1deD2QykAb9FVuhLWFScKEjQJ.Pl6m6nJlvxYaYFtCO/O', 1, 1, NULL, '2020-08-21 23:18:09', '2020-08-21 23:18:09'),
(6, 'Malcolm Harvey PhD', 'iernser@luettgen.com', NULL, '$2y$10$JlpTyRIqRQzRUwngxivHq.O2ggaNOjox/ar8PH8s6YUad5tB9.JSi', 1, 1, NULL, '2020-08-21 23:18:09', '2020-08-21 23:18:09'),
(7, 'Dr. Tyree Feeney PhD', 'kaci.franecki@gmail.com', NULL, '$2y$10$A3u0S2XdbsfUuTJnMEpzSeX.Q2OulHmLq5.VXyv1oOdgW1jEt7WMi', 1, 1, NULL, '2020-08-21 23:18:09', '2020-08-21 23:18:09'),
(8, 'Nannie Friesen', 'carlo43@gmail.com', NULL, '$2y$10$C9RPodBEOzQJnl7Hvs.Ot.oL.BcIr8CJWL1IPFT73sRYTH4fjfM7a', 1, 1, NULL, '2020-08-21 23:18:09', '2020-08-21 23:18:09'),
(9, 'Diana Lopez', 'qrippin@kuhn.com', NULL, '$2y$10$CsPSfu4pNdLYuh4bGMvMxOWE8YAX66tNMLhXlgI0gL/MjzBDm54m.', 1, 1, NULL, '2020-08-21 23:18:10', '2020-08-21 23:18:10'),
(10, 'Mozell Ward', 'rherman@yahoo.com', NULL, '$2y$10$Vp4iihfw1bmjwo8B4L9ZFul3M6jBYHVxAAdVjq9Y./GiWlDIww3gO', 2, 3, NULL, '2020-08-21 23:18:10', '2020-08-22 00:27:03'),
(12, 'Pedro Perez', 'pedro@pedro.com', NULL, '$2y$10$gdASKajPd4MV.LB5A3l/UuqtiD4gVIyWgGgjmQVlWhbbKZfF4f4jG', 1, 1, NULL, '2020-08-21 23:48:05', '2020-08-21 23:48:05'),
(14, 'Test', 'test@test.com', NULL, '123456789', 1, 1, NULL, NULL, NULL),
(16, 'Pedro1 Perez', 'pedro1@pedro.com', NULL, '123456789', 1, 3, NULL, NULL, NULL),
(18, 'Nestor', 'nestorlerma1609@gmail.com', NULL, '123456', 1, 3, NULL, NULL, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categories_status_id_foreign` (`status_id`);

--
-- Indices de la tabla `category_movie`
--
ALTER TABLE `category_movie`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_movie_movie_id_foreign` (`movie_id`),
  ADD KEY `category_movie_category_id_foreign` (`category_id`);

--
-- Indices de la tabla `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `movies_user_id_foreign` (`user_id`),
  ADD KEY `movies_status_id_foreign` (`status_id`);

--
-- Indices de la tabla `movie_rental`
--
ALTER TABLE `movie_rental`
  ADD PRIMARY KEY (`id`),
  ADD KEY `movie_rental_movie_id_foreign` (`movie_id`),
  ADD KEY `movie_rental_rental_id_foreign` (`rental_id`);

--
-- Indices de la tabla `rentals`
--
ALTER TABLE `rentals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rentals_user_id_foreign` (`user_id`),
  ADD KEY `rentals_status_id_foreign` (`status_id`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `roles_status_id_foreign` (`status_id`);

--
-- Indices de la tabla `statuses`
--
ALTER TABLE `statuses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `statuses_type_status_id_foreign` (`type_status_id`);

--
-- Indices de la tabla `type_statuses`
--
ALTER TABLE `type_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_status_id_foreign` (`status_id`),
  ADD KEY `users_role_id_foreign` (`role_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `category_movie`
--
ALTER TABLE `category_movie`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `movies`
--
ALTER TABLE `movies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `movie_rental`
--
ALTER TABLE `movie_rental`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `rentals`
--
ALTER TABLE `rentals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `statuses`
--
ALTER TABLE `statuses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de la tabla `type_statuses`
--
ALTER TABLE `type_statuses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `category_movie`
--
ALTER TABLE `category_movie`
  ADD CONSTRAINT `category_movie_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `category_movie_movie_id_foreign` FOREIGN KEY (`movie_id`) REFERENCES `movies` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `movies`
--
ALTER TABLE `movies`
  ADD CONSTRAINT `movies_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `movies_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `movie_rental`
--
ALTER TABLE `movie_rental`
  ADD CONSTRAINT `movie_rental_movie_id_foreign` FOREIGN KEY (`movie_id`) REFERENCES `movies` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `movie_rental_rental_id_foreign` FOREIGN KEY (`rental_id`) REFERENCES `rentals` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `rentals`
--
ALTER TABLE `rentals`
  ADD CONSTRAINT `rentals_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `rentals_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `roles`
--
ALTER TABLE `roles`
  ADD CONSTRAINT `roles_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `statuses`
--
ALTER TABLE `statuses`
  ADD CONSTRAINT `statuses_type_status_id_foreign` FOREIGN KEY (`type_status_id`) REFERENCES `type_statuses` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `users_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
